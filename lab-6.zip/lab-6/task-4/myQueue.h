#include <stack>
#include "Queue.h"
#include <iostream>

using namespace std;

template <class T>
class myQueue : public AbstractQueue<T> {
private:
    T* arr;
    int frontIndex;
    int rearIndex;
    int capacity;
    int size;

public:
    myQueue(int s);
    ~myQueue();
    void enQueue(T value) ;
    T deQueue() ;
    T front()  ;
    bool isEmpty()  ;
    bool isFull()  ;
    void Display()  ;
    void reverseFirstKElements(int k);
};

template <class T>
myQueue<T>::myQueue(int s) : capacity(s), size(0), frontIndex(0), rearIndex(-1) {
    arr = new T[capacity];
}

template <class T>
myQueue<T>::~myQueue() {
    delete[] arr;
}

template <class T>
void myQueue<T>::enQueue(T value) {
    if (isFull()) {
        cout << "Queue is Full!" << endl;
        return;
    }
    rearIndex++;
    arr[rearIndex] = value;
    size++;
}

template <class T>
T myQueue<T>::deQueue() {
    if (isEmpty()) {
        cout << "Queue is Empty!" << endl;
        return T();
    }
    T frontElement = arr[frontIndex];
    frontIndex++;
    size--;
    return frontElement;
}

template <class T>
T myQueue<T>::front()  {
    if (isEmpty()) {
        cout << "Queue is Empty!" << endl;
        return T();
    }
    return arr[frontIndex];
}

template <class T>
bool myQueue<T>::isEmpty()  {
    return size == 0;
}

template <class T>
bool myQueue<T>::isFull()  {
    return rearIndex - frontIndex + 1 == capacity;
}

template <class T>
void myQueue<T>::Display()  {
    if (isEmpty()) {
        cout << "Queue is Empty!" << endl;
        return;
    }
    cout << "Queue Elements: ";
    for (int i = frontIndex; i <= rearIndex; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}

template <class T>
void myQueue<T>::reverseFirstKElements(int k) {
    if (k <= 0 || k > size) {
        cout << "Invalid value of K. No changes made to the queue." << endl;                                                                                                                             
        return;
    }
    stack<T> tempStack;
    for (int i = 0; i < k; i++) {
        tempStack.push(deQueue());
    }
    while (!tempStack.empty()) {
        enQueue(tempStack.top());
        tempStack.pop();
    }

    int remaining = size - k;
    for (int i = 0; i < remaining; i++) {
        enQueue(deQueue());
    }
}
