#include "myQueue.h"
#include <iostream>
using namespace std;

int main() {
    int capacity;
    cout << "Enter the maximum number of tickets the system can handle: ";
    cin >> capacity;

    myQueue<int> ticketQueue(capacity);
    int choice, ticketID;

    do {
        cout << "\nCustomer Support Ticket System Menu:\n";
        cout << "1. Add a new ticket\n";
        cout << "2. Resolve and remove the ticket\n";
        cout << "3. Check the next ticket to be resolved\n";
        cout << "4. Display all pending tickets\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter the 4-digit ticket ID: ";
            cin >> ticketID;
            if (ticketID < 1000 || ticketID > 9999) {
                cout << "Invalid ticket ID! Please enter a 4-digit number." << endl;
            }
            else {
                ticketQueue.enQueue(ticketID);
            }
            break;
        case 2:
            ticketID = ticketQueue.deQueue();
            if (ticketID != 0) {
                cout << "Resolved and removed ticket ID: " << ticketID << endl;
            }
            break;
        case 3:
            ticketID = ticketQueue.front();
            if (ticketID != 0) {
                cout << "Next ticket to be resolved: " << ticketID << endl;
            }
            break;
        case 4:
            cout << "Pending tickets: ";
            ticketQueue.Display();
            break;
        case 5:
            cout << "Exiting the system. Goodbye!" << endl;
            break;
        default:
            cout << "Invalid choice! Please try again." << endl;
        }
    } while (choice != 5);

    return 0;
}
