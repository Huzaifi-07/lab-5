#include "myQueue.h"
#include <iostream>
#include <string>

using namespace std;

int main() {
    int capacity;
    cout << "Enter the maximum number of print jobs the queue can handle: ";
    cin >> capacity;

    myQueue<string> printQueue(capacity);
    int choice;
    string documentName;

    do {
        cout << "\nDocument Printing System Menu:\n";
        cout << "1. Add a new print job\n";
        cout << "2. Print the document at the front\n";
        cout << "3. Check the front document\n";
        cout << "4. Display all pending print jobs\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter the document name: ";
            cin.ignore(); // To ignore the newline character left in the input buffer
            getline(cin, documentName);
            printQueue.enQueue(documentName);
            break;
        case 2:
            documentName = printQueue.deQueue();
            if (!documentName.empty()) {
                cout << "Printing document: " << documentName << endl;
            }
            break;
        case 3:
            documentName = printQueue.front();
            if (!documentName.empty()) {
                cout << "Next document to print: " << documentName << endl;
            }
            break;
        case 4:
            printQueue.Display();
            break;
        case 5:
            cout << "Exiting the system. Goodbye!" << endl;
            break;
        default:
            cout << "Invalid choice! Please try again." << endl;
        }
    } while (choice != 5);

    return 0;
}

