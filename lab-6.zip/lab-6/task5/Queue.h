#include<iostream>
using namespace std;
template <typename T>
class AbstractQueue {
public:
	int* arr;
	int cSize, mSize;
	AbstractQueue(int size) : mSize(size) {
		cSize = 0;
		arr = new int[mSize];
		//cout << "start q";
	}
	virtual void enQueue(T value) = 0;
	virtual T deQueue() = 0;
	virtual T front() = 0;
	virtual bool isEmpty() = 0;
	virtual bool isFull() = 0;
	virtual void Display() = 0;

	virtual ~AbstractQueue() {}
};