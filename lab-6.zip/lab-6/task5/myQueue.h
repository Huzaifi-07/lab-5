#include "Queue.h"
#include <iostream>
#include <string>

using namespace std;

template <class T>
class myQueue : public AbstractQueue<T> {
private:
    T* arr;
    int frontIndex;
    int rearIndex;
    int capacity;
    int size;

public:
    myQueue(int s);
    ~myQueue();
    void enQueue(T value) ;
    T deQueue() ;
    T front()  ;
    bool isEmpty()  ;
    bool isFull()  ;
    void Display()  ;
};

template <class T>
myQueue<T>::myQueue(int s) : AbstractQueue<T>(s), capacity(s), size(0), frontIndex(0), rearIndex(-1) {
    arr = new T[capacity];
}


template <class T>
myQueue<T>::~myQueue() {
    delete[] arr;
}

template <class T>
void myQueue<T>::enQueue(T value) {
    if (isFull()) {
        cout << "Queue is Full! Cannot add more print jobs." << endl;
        return;
    }
    rearIndex++;
    arr[rearIndex] = value;
    size++;
}

template <class T>
T myQueue<T>::deQueue() {
    if (isEmpty()) {
        cout << "Queue is Empty! No print jobs to process." << endl;
        return T();
    }
    T frontElement = arr[frontIndex];
    frontIndex++;
    size--;
    return frontElement;
}

template <class T>
T myQueue<T>::front()  {
    if (isEmpty()) {
        cout << "Queue is Empty! No print jobs to check." << endl;
        return T();
    }
    return arr[frontIndex];
}

template <class T>
bool myQueue<T>::isEmpty()  {
    return size == 0;
}

template <class T>
bool myQueue<T>::isFull()  {
    return rearIndex - frontIndex + 1 == capacity;
}

template <class T>
void myQueue<T>::Display()  {
    if (isEmpty()) {
        cout << "Queue is Empty! No print jobs to display." << endl;
        return;
    }
    cout << "Pending Print Jobs: ";
    for (int i = frontIndex; i <= rearIndex; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}

