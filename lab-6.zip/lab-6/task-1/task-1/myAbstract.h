#include "abstract.h"

template <class T>
class myQueue :public Queue<T>
{
public:
	void enqueue(T value);
	T dequeue();
	myQueue(int s);
	void display();
	bool isEmpty();
	bool isFull();
	T front();
};

template <class T>
bool myQueue<T>::isFull()		
{
	return Queue<T>::maxSize == Queue<T>::currentSize;
}

template <class T>
bool myQueue<T>::isEmpty()			
{
	return Queue<T>::currentSize == 0;
}

template <class T>
void myQueue<T>::display()				
{
	
	for (int i = 0; i < Queue<T>::currentSize; i++)
		cout << i << ". " << Queue<T>::arr[i] << endl;
}

template <class T>
myQueue<T>::myQueue(int s) :Queue<T>(s)
{

}

template <class T>				
void myQueue<T>::enqueue(T value)
{
	if (isFull())
	{
		cout << "Queue is FULL" << endl;
	}

	else
	{
		Queue<T>::arr[Queue<T>::currentSize] = value;
		Queue<T>::currentSize++;
	}

}

template <class T>			
T myQueue<T>::dequeue()
{
	if (isEmpty())
	{
		cout << "Queue is Empty" << endl;
		return NULL;
	}

	else
	{
		T returningValue = Queue<T>::arr[0];
		Queue<T>::currentSize--;
		for (int i = 0; i < Queue<T>::currentSize; i++)
		{
			Queue<T>::arr[i] = Queue<T>::arr[i + 1];
		}

		return returningValue;
	}

}

template<typename T>
T myQueue<T>::front() 
{
	if (isEmpty()) {
		cout << " Queue is empty " << endl;
		return NULL;
	}
	else
	{
		T returningValue = Queue<T>::arr[0];

		for (int i = 0; i < Queue<T>::currentSize; i++)
		{
			Queue<T>::arr[i] = Queue<T>::arr[i + 1];
	   }
		return returningValue;
	}


}