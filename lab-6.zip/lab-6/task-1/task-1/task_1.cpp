#include"myAbstract.h"

int main()
{
	myQueue<int> obj(5);

	int choice = 0;
	int val;
	cout << "1: Enqueue Value" << endl;
	cout << "2: dequeue Value" << endl;
	cout << "3: front Value" << endl;
	cout << "4: display queue" << endl;
	cout << "5: Exit" << endl;
	do {
		
		cout << " Enter Choice" << endl;
		cin >> choice;
		if (choice == 1)
		{
			cout << "Enter Value" << endl;
			cin >> val;
			obj.enqueue(val);
		}
		else if (choice == 2)
		{
			obj.dequeue();
			cout << "After dequeue the queue is " << endl;
			obj.display();

		}
		else if  (choice == 3)
		{
			obj.front();
			cout << "After front the queue is " << endl;
			obj.display();

		}
		else if (choice == 4)
		{
			cout << " The queue is " << endl;
			obj.display();
		}
		
	
	} while (choice != 5);
	


}