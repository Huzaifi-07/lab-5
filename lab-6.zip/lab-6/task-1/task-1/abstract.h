#include <iostream>
#include <string>
using namespace std;

template <class T>
class Queue
{
protected:
	T* arr;
	int maxSize;
	int currentSize;
public:
	Queue(int size);
	~Queue();
	virtual void enqueue(T value) = 0;
	virtual T dequeue() = 0;
	virtual bool isEmpty() = 0;
	virtual bool isFull() = 0;
	virtual T front() = 0;
	
};

template <class T>
Queue<T>::Queue(int size)
{
	maxSize = size;
	currentSize = 0;
	arr = new T[size];
}

template<typename T>
Queue<T>::~Queue()
{
	delete[] arr;
}