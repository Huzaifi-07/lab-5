#include "myQueue.h"
#include <iostream>
using namespace std;

int main() {
    int capacity;
    cout << "Enter the capacity of the queue: ";
    cin >> capacity;

    myQueue<int> queue(capacity);

    cout << "Enter the number of elements to enqueue: ";
    int n;
    cin >> n;

    cout << "Enter the elements of the queue: ";
    for (int i = 0; i < n; i++) {
        int value;
        cin >> value;
        queue.enQueue(value);
    }

    cout << "Enter the value of K (number of elements to reverse): ";
    int k;
    cin >> k;

    cout << "Original Queue: ";
    queue.Display();

    queue.reverseFirstKElements(k);

    cout << "Queue after reversing first " << k << " elements: ";
    queue.Display();

    return 0;
}