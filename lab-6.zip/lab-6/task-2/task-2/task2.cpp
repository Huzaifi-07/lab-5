#include"mystack.h"

int main()
{
	myStack<int>original(5);
	original.push(1);
	original.push(2);
	original.push(3);
	original.push(4);
	original.push(5);

	cout << "Orignal stack is " << endl;
	original.display();

	myStack<int>stack2(5);

	while (!original.isEmpty()) {
		stack2.push(original.pop());
	}


	while (!stack2.isEmpty()) {
		original.push(stack2.pop());
	}

	cout << "The emplementation of que is by using two stack  " << endl;
	original.display();






}